import React, { useState, useEffect, useCallback } from "react";

// ═════════════════════════════════════════════════════════════════════════════
// 50 LEVELS - Placeholder structure. Fill content later.
// ═════════════════════════════════════════════════════════════════════════════
const LEVELS = Array.from({length: 50}, (_, i) => ({
  id: i + 1,
  title: `Story ${i + 1}`,
  icon: ["🌅","🍎","🌊","🗼","⭐","👑","🔥","📜","⚔️","💎","⚡","🦁","🐋","✨","🍞","🍷","🌸","💫","🌟","🕊️","⛪","📖","🎺","🌾","🏔️","🌟","🔔","🎭","🌳","🗝️","⚖️","🎨","🌺","📯","🛡️","🌙","☀️","🌈","🎵","📿","🕯️","⚱️","🏛️","🌍","👶","🎁","🌬️","🏺","⚓","🦅"][i] || "📖",
  era: ["Creation","Eden","Early Earth","Patriarchs","Exodus","Kingdom","Captivity","New Testament","Ministry","Passion","Early Church","Prophecy"][Math.floor(i / 4)] || "Scripture",
  summary: `This is a placeholder summary for story ${i + 1}. Replace with actual Bible story content.`,
  scripture: [
    { ref: `Placeholder ${i + 1}:1-3`, text: `Placeholder scripture text for story ${i + 1}. Replace with actual KJV verses.` }
  ],
  questions: [
    { q: `Question 1 for story ${i + 1}?`, options: ["A","B","C","D"], correct: 0, ref: `Ref ${i + 1}:1` },
    { q: `Question 2 for story ${i + 1}?`, options: ["A","B","C","D"], correct: 1, ref: `Ref ${i + 1}:2` },
    { q: `Question 3 for story ${i + 1}?`, options: ["A","B","C","D"], correct: 2, ref: `Ref ${i + 1}:3` },
  ],
  studyNotes: `Placeholder study notes for story ${i + 1}. Add historical context, cross-references, and theological insights here.`
}));

const SCREENS = { MAP: "map", STORY: "story", QUIZ: "quiz", RESULT: "result", BADGES: "badges", STATS: "stats", SETTINGS: "settings" };

const BADGE_DEFS = [
  { id: "first", title: "First Step", icon: "👣", desc: "Completed 1 story", threshold: 1 },
  { id: "learner", title: "Learner", icon: "📚", desc: "Completed 3 stories", threshold: 3 },
  { id: "seeker", title: "Seeker", icon: "🔍", desc: "Completed 5 stories", threshold: 5 },
  { id: "devoted", title: "Devoted", icon: "🙏", desc: "Completed 10 stories", threshold: 10 },
  { id: "explorer", title: "Explorer", icon: "🗺️", desc: "Completed 15 stories", threshold: 15 },
  { id: "disciple", title: "Disciple", icon: "✝️", desc: "Completed 20 stories", threshold: 20 },
  { id: "scholar", title: "Scholar", icon: "📖", desc: "Completed 30 stories", threshold: 30 },
  { id: "teacher", title: "Teacher", icon: "👨‍🏫", desc: "Completed 40 stories", threshold: 40 },
  { id: "master", title: "Master", icon: "🎓", desc: "Completed all 50 stories!", threshold: 50 },
  { id: "perfect_1", title: "Perfect Start", icon: "⭐", desc: "Got 3/3 on first story", special: true },
  { id: "streak_7", title: "Week Warrior", icon: "🔥", desc: "7-day streak", special: true },
  { id: "streak_30", title: "Month Master", icon: "📅", desc: "30-day streak", special: true },
  { id: "early_bird", title: "Early Bird", icon: "🌅", desc: "Completed a story before 8am", special: true },
  { id: "night_owl", title: "Night Owl", icon: "🦉", desc: "Completed a story after 10pm", special: true },
  { id: "speed_demon", title: "Speed Reader", icon: "⚡", desc: "Completed quiz in under 60s", special: true },
];

// ── SPINNER COMPONENT ─────────────────────────────────────────────────────────
function Spinner() {
  return <div style={{width:32,height:32,borderRadius:"50%",border:"3px solid #2a251d",borderTopColor:"#d4a574",animation:"spin 0.8s linear infinite"}} />;
}

// ═════════════════════════════════════════════════════════════════════════════
export default function BibleAdventure() {
  const [screen, setScreen] = useState(SCREENS.MAP);
  const [completed, setCompleted] = useState([]);
  const [badges, setBadges] = useState([]);
  const [streak, setStreak] = useState(0);
  const [current, setCurrent] = useState(null);
  const [quizState, setQuizState] = useState({ idx: 0, picked: null, score: 0, startTime: 0 });
  const [newBadge, setNewBadge] = useState(null);
  const [mounted, setMounted] = useState(false);
  const [settings, setSettings] = useState({ audioEnabled: true, autoPlay: false, narrationSpeed: 1.0, musicEnabled: true, musicVolume: 0.3, hapticsEnabled: true, theme: "dark" });
  const [isNarrating, setIsNarrating] = useState(false);
  const [showStudyNotes, setShowStudyNotes] = useState(false);
  const [bgMusic, setBgMusic] = useState(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [dailyChallenge, setDailyChallenge] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterEra, setFilterEra] = useState("all");
  const [favorites, setFavorites] = useState([]);
  const [showShareModal, setShowShareModal] = useState(false);
  const [quizHistory, setQuizHistory] = useState([]);
  const [showCalendar, setShowCalendar] = useState(false);
  const [completionDates, setCompletionDates] = useState({});
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // ── LOAD ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    const load = async () => {
      try { const r = await window.storage.get("ba_completed"); if (r) setCompleted(JSON.parse(r.value)); } catch(e) {}
      try { const r = await window.storage.get("ba_badges"); if (r) setBadges(JSON.parse(r.value)); } catch(e) {}
      try { const r = await window.storage.get("ba_settings"); if (r) setSettings(JSON.parse(r.value)); } catch(e) {}
      try { const r = await window.storage.get("ba_favorites"); if (r) setFavorites(JSON.parse(r.value)); } catch(e) {}
      try { const r = await window.storage.get("ba_quiz_history"); if (r) setQuizHistory(JSON.parse(r.value)); } catch(e) {}
      try { const r = await window.storage.get("ba_completion_dates"); if (r) setCompletionDates(JSON.parse(r.value)); } catch(e) {}
      try {
        const l = await window.storage.get("ba_last");
        const s = await window.storage.get("ba_streak");
        if (l && s) { const d = (Date.now() - Number(l.value)) / 86400000; setStreak(d <= 1.5 ? Number(s.value) : 0); }
      } catch(e) {}
      
      // Daily Challenge - random unlocked story
      try {
        const today = new Date().toDateString();
        const lastChallenge = await window.storage.get("ba_challenge_date");
        if (!lastChallenge || lastChallenge.value !== today) {
          const comp = await window.storage.get("ba_completed");
          const completedIds = comp ? JSON.parse(comp.value) : [];
          const unlockedLevels = LEVELS.filter((_, i) => i === 0 || completedIds.includes(LEVELS[i-1].id));
          if (unlockedLevels.length > 0) {
            const seed = new Date().getDate();
            const challenge = unlockedLevels[seed % unlockedLevels.length];
            setDailyChallenge(challenge);
            await window.storage.set("ba_challenge_date", today);
            await window.storage.set("ba_challenge", JSON.stringify(challenge));
          }
        } else {
          const saved = await window.storage.get("ba_challenge");
          if (saved) setDailyChallenge(JSON.parse(saved.value));
        }
      } catch(e) {}
      
      setMounted(true);
    };
    load();

    // Initialize background music
    // Using copyright-free ambient music from various free sources
    const audio = new Audio();
    // Free ambient peaceful music - you can replace with any copyright-free track
    // Example sources: YouTube Audio Library, Incompetech, Purple Planet, Bensound
    audio.src = "https://cdn.pixabay.com/audio/2022/03/10/audio_19c2e5e03b.mp3"; // Free ambient peaceful music from Pixabay
    audio.loop = true;
    audio.volume = 0;
    setBgMusic(audio);

    return () => {
      if (audio) {
        audio.pause();
        audio.src = "";
      }
    };
  }, []);

  // ── HAPTIC FEEDBACK ────────────────────────────────────────────────────────
  const haptic = useCallback((type = "light") => {
    if (!settings.hapticsEnabled) return;
    if (navigator.vibrate) {
      const patterns = {
        light: [10],
        medium: [20],
        heavy: [30],
        success: [10, 50, 10],
        error: [50, 100, 50],
      };
      navigator.vibrate(patterns[type] || patterns.light);
    }
  }, [settings.hapticsEnabled]);

  // ── NOTIFICATION SYSTEM ─────────────────────────────────────────────────────
  const showNotification = useCallback((message, type = "info") => {
    const id = Date.now();
    const notification = { id, message, type };
    setNotifications(prev => [...prev, notification]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  }, []);

  // ── OFFLINE DETECTION ──────────────────────────────────────────────────────
  useEffect(() => {
    const handleOnline = () => { 
      setIsOffline(false); 
      showNotification("🟢 Back online", "success"); 
    };
    const handleOffline = () => { 
      setIsOffline(true); 
      showNotification("🔴 Offline mode - progress still saves", "info"); 
    };
    
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [showNotification]);

  // ── BACKGROUND MUSIC CONTROL ───────────────────────────────────────────────
  useEffect(() => {
    if (!bgMusic) return;
    
    if (settings.musicEnabled && mounted) {
      // Fade in
      bgMusic.volume = 0;
      bgMusic.play().then(() => {
        setIsMusicPlaying(true);
        let vol = 0;
        const fadeIn = setInterval(() => {
          vol += 0.02;
          if (vol >= settings.musicVolume) {
            bgMusic.volume = settings.musicVolume;
            clearInterval(fadeIn);
          } else {
            bgMusic.volume = vol;
          }
        }, 50);
      }).catch(e => {
        console.log("Music autoplay blocked or error:", e);
        setIsMusicPlaying(false);
      });
    } else {
      // Fade out
      let vol = bgMusic.volume;
      const fadeOut = setInterval(() => {
        vol -= 0.02;
        if (vol <= 0) {
          bgMusic.volume = 0;
          bgMusic.pause();
          setIsMusicPlaying(false);
          clearInterval(fadeOut);
        } else {
          bgMusic.volume = vol;
        }
      }, 50);
    }
  }, [settings.musicEnabled, mounted, bgMusic]);

  // Update volume when changed
  useEffect(() => {
    if (bgMusic && isMusicPlaying) {
      try {
        bgMusic.volume = settings.musicVolume;
      } catch (e) {
        console.error("Error setting volume:", e);
      }
    }
  }, [settings.musicVolume, bgMusic, isMusicPlaying]);

  // ── SAVE ──────────────────────────────────────────────────────────────────
  const save = useCallback(async (comp, badg, str, history = null, dates = null) => {
    try { await window.storage.set("ba_completed", JSON.stringify(comp)); } catch(e) {}
    try { await window.storage.set("ba_badges", JSON.stringify(badg)); } catch(e) {}
    try { await window.storage.set("ba_last", String(Date.now())); } catch(e) {}
    try { await window.storage.set("ba_streak", String(str)); } catch(e) {}
    if (history) {
      try { await window.storage.set("ba_quiz_history", JSON.stringify(history)); } catch(e) {}
    }
    if (dates) {
      try { await window.storage.set("ba_completion_dates", JSON.stringify(dates)); } catch(e) {}
    }
  }, []);

  const saveSettings = useCallback(async (newSettings) => {
    setSettings(newSettings);
    try { await window.storage.set("ba_settings", JSON.stringify(newSettings)); } catch(e) {}
  }, []);

  // ── TEXT-TO-SPEECH (Free Web Speech API) ─────────────────────────────────
  const speak = useCallback((text) => {
    if (!settings.audioEnabled || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = settings.narrationSpeed;
      utterance.onstart = () => setIsNarrating(true);
      utterance.onend = () => setIsNarrating(false);
      utterance.onerror = () => setIsNarrating(false);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error("Speech synthesis error:", e);
      setIsNarrating(false);
    }
  }, [settings]);

  const stopSpeech = useCallback(() => {
    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        setIsNarrating(false);
      }
    } catch (e) {
      console.error("Error stopping speech:", e);
    }
  }, []);

  // ── NAV ───────────────────────────────────────────────────────────────────
  const openLevel = (lv) => {
    haptic("light");
    setCurrent(lv);
    setScreen(SCREENS.STORY);
    setShowStudyNotes(false);
    stopSpeech();
    if (settings.autoPlay) {
      setTimeout(() => speak(lv.summary + ". " + lv.scripture.map(s => s.text).join(". ")), 500);
    }
  };

  const openDailyChallenge = () => {
    if (dailyChallenge) {
      try {
        showNotification("📅 Daily Challenge Started!", "success");
        openLevel(dailyChallenge);
      } catch (e) {
        console.error("Error opening daily challenge:", e);
      }
    }
  };

  // ── FAVORITES ──────────────────────────────────────────────────────────────
  const toggleFavorite = useCallback(async (levelId) => {
    haptic("light");
    const newFavorites = favorites.includes(levelId)
      ? favorites.filter(id => id !== levelId)
      : [...favorites, levelId];
    setFavorites(newFavorites);
    try { await window.storage.set("ba_favorites", JSON.stringify(newFavorites)); } catch(e) {}
    showNotification(favorites.includes(levelId) ? "Removed from favorites" : "Added to favorites ⭐", "info");
  }, [favorites, haptic, showNotification]);

  // ── CLIPBOARD HELPERS ──────────────────────────────────────────────────────
  const fallbackCopy = useCallback((text) => {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      showNotification("Progress copied! 📋", "success");
    } catch (e) {
      showNotification("Couldn't copy - please share manually", "info");
    }
    document.body.removeChild(textarea);
  }, [showNotification]);

  const copyToClipboard = useCallback((text) => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(() => showNotification("Progress copied to clipboard! 📋", "success"))
        .catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
  }, [showNotification, fallbackCopy]);

  // ── SHARE PROGRESS ─────────────────────────────────────────────────────────
  const shareProgress = useCallback(() => {
    haptic("medium");
    const text = `📖 I've completed ${completed.length}/${LEVELS.length} Bible stories with a ${streak}-day streak! 🔥\n\nJoin me on Bible Adventure!`;
    
    if (navigator.share) {
      navigator.share({ text, title: "My Bible Adventure Progress" })
        .then(() => showNotification("Shared successfully! 🎉", "success"))
        .catch((err) => {
          if (err.name !== 'AbortError') {
            copyToClipboard(text);
          }
        });
    } else {
      copyToClipboard(text);
    }
    setShowShareModal(false);
  }, [completed.length, streak, haptic, showNotification, copyToClipboard]);

  // ── READING TIME ESTIMATE ──────────────────────────────────────────────────
  const getReadingTime = useCallback((story) => {
    const words = story.summary.split(" ").length + 
                  story.scripture.reduce((acc, s) => acc + s.text.split(" ").length, 0);
    const minutes = Math.ceil(words / 200); // Average reading speed
    return minutes;
  }, []);

  // ── ACTIVITY CALENDAR ──────────────────────────────────────────────────────
  const getLast30Days = useCallback(() => {
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const hasActivity = completionDates && Object.values(completionDates).includes(dateStr);
      days.push({ date: dateStr, hasActivity, day: date.getDate(), month: date.getMonth() });
    }
    return days;
  }, [completionDates]);

  // ── PERFORMANCE STATS ──────────────────────────────────────────────────────
  const getAverageScore = useCallback(() => {
    if (quizHistory.length === 0) return 0;
    const total = quizHistory.reduce((acc, h) => acc + (h.score / h.totalQuestions * 100), 0);
    return Math.round(total / quizHistory.length);
  }, [quizHistory]);

  const getFastestQuiz = useCallback(() => {
    if (!quizHistory || quizHistory.length === 0) return null;
    return quizHistory.reduce((fastest, curr) => 
      !fastest || curr.duration < fastest.duration ? curr : fastest
    , null);
  }, [quizHistory]);

  const startQuiz = () => {
    haptic("medium");
    setQuizState({ idx: 0, picked: null, score: 0, startTime: Date.now() });
    setScreen(SCREENS.QUIZ);
    stopSpeech();
  };

  const pickAnswer = (i) => {
    if (quizState.picked !== null) return;
    const isCorrect = i === current.questions[quizState.idx].correct;
    haptic(isCorrect ? "success" : "error");
    setQuizState(prev => ({ ...prev, picked: i, score: prev.score + (i === current.questions[prev.idx].correct ? 1 : 0) }));
  };

  const nextQ = () => {
    if (quizState.idx < current.questions.length - 1) {
      haptic("light");
      setQuizState(prev => ({ ...prev, idx: prev.idx + 1, picked: null }));
    } else {
      const passed = quizState.score >= 2;
      const duration = (Date.now() - quizState.startTime) / 1000;
      
      if (passed && !completed.includes(current.id)) {
        haptic("heavy");
        const newComp = [...completed, current.id];
        const newStr = streak + 1;
        let earned = [...badges], newBadges = [];

        // Track quiz attempt
        const quizAttempt = {
          levelId: current.id,
          score: quizState.score,
          totalQuestions: current.questions.length,
          timestamp: Date.now(),
          duration: Math.round(duration),
        };
        const newHistory = [...quizHistory, quizAttempt];
        setQuizHistory(newHistory);

        // Track completion date for calendar
        const newDates = { ...completionDates, [current.id]: new Date().toISOString().split('T')[0] };
        setCompletionDates(newDates);

        // Progress badges
        for (const bd of BADGE_DEFS.filter(b => !b.special)) {
          if (newComp.length >= bd.threshold && !earned.find(e => e.id === bd.id)) {
            earned.push(bd);
            newBadges.push(bd);
          }
        }

        // Special badges
        if (current.id === 1 && quizState.score === 3 && !earned.find(e => e.id === "perfect_1")) {
          const perfectBadge = BADGE_DEFS.find(b => b.id === "perfect_1");
          earned.push(perfectBadge);
          newBadges.push(perfectBadge);
        }
        if (newStr === 7 && !earned.find(e => e.id === "streak_7")) {
          const streakBadge = BADGE_DEFS.find(b => b.id === "streak_7");
          earned.push(streakBadge);
          newBadges.push(streakBadge);
        }
        if (newStr === 30 && !earned.find(e => e.id === "streak_30")) {
          const streakBadge = BADGE_DEFS.find(b => b.id === "streak_30");
          earned.push(streakBadge);
          newBadges.push(streakBadge);
        }
        const hour = new Date().getHours();
        if (hour < 8 && !earned.find(e => e.id === "early_bird")) {
          const earlyBadge = BADGE_DEFS.find(b => b.id === "early_bird");
          earned.push(earlyBadge);
          newBadges.push(earlyBadge);
        }
        if (hour >= 22 && !earned.find(e => e.id === "night_owl")) {
          const nightBadge = BADGE_DEFS.find(b => b.id === "night_owl");
          earned.push(nightBadge);
          newBadges.push(nightBadge);
        }
        if (duration < 60 && !earned.find(e => e.id === "speed_demon")) {
          const speedBadge = BADGE_DEFS.find(b => b.id === "speed_demon");
          earned.push(speedBadge);
          newBadges.push(speedBadge);
        }

        setCompleted(newComp);
        setBadges(earned);
        setStreak(newStr);
        save(newComp, earned, newStr, newHistory, newDates);
        setScreen(SCREENS.RESULT);
        
        if (newBadges.length > 0) {
          setTimeout(() => {
            haptic("success");
            setNewBadge(newBadges[0]);
          }, 600);
        }
      } else {
        haptic("medium");
        setScreen(SCREENS.RESULT);
      }
    }
  };

  // ── DERIVED ───────────────────────────────────────────────────────────────
  const progressPct = (completed.length / LEVELS.length) * 100;
  const passed = quizState.score >= 2;

  // ── THEME COLORS ──────────────────────────────────────────────────────────
  const themes = {
    dark: { bg: "#0a0908", bgAlt: "#0f0e0c", card: "#1a1712", border: "#2a251d", text: "#e8dcc8", textSub: "#b8ad94", textMuted: "#6a6049", accent: "#d4a574" },
    light: { bg: "#f5f1e8", bgAlt: "#ebe7de", card: "#ffffff", border: "#d4c9b0", text: "#2a251d", textSub: "#5a4f3f", textMuted: "#8a7d5a", accent: "#c9a063" },
    sepia: { bg: "#e8dcc8", bgAlt: "#d8cdb5", card: "#f0e8d8", border: "#c9ba9f", text: "#3a2f1f", textSub: "#5a4a2f", textMuted: "#7a6a4a", accent: "#b8946a" },
  };
  const theme = themes[settings.theme] || themes.dark;

  // Filtered levels based on search and era
  const filteredLevels = LEVELS.filter(lv => {
    const matchesSearch = lv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lv.era.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesEra = filterEra === "all" || lv.era === filterEra;
    return matchesSearch && matchesEra;
  });

  const eras = ["all", ...new Set(LEVELS.map(lv => lv.era))];
  const totalReadingTime = LEVELS.reduce((acc, lv) => acc + getReadingTime(lv), 0);

  if (!mounted) return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(to bottom, ${theme.bg} 0%, ${theme.bgAlt} 50%, ${theme.bg} 100%)`, color: theme.text, fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, padding: "60px 20px" }}>
        <Spinner />
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", color: "#e8dcc8", fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", paddingBottom: 40, background: `linear-gradient(to bottom, ${theme.bg} 0%, ${theme.bgAlt} 50%, ${theme.bg} 100%)` }}>
      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes slideDown{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
        @keyframes glow{0%,100%{box-shadow:0 0 15px ${theme.accent}80}50%{box-shadow:0 0 30px ${theme.accent}cc}}
        @keyframes shimmer{0%{background-position:200% center}100%{background-position:-200% center}}
        .card{transition:all 0.3s cubic-bezier(0.4,0,0.2,1)}
        .card:hover{transform:translateY(-4px) scale(1.02);box-shadow:0 8px 30px rgba(0,0,0,0.3)}
        .btn{transition:all 0.2s ease}
        .btn:hover{transform:translateY(-2px);filter:brightness(1.15)}
        .opt:hover{background:${theme.card}!important;border-color:${theme.accent}80!important}
        .nav-btn{opacity:0.7;transition:opacity 0.2s}
        .nav-btn:hover{opacity:1}
      `}</style>

      {/* ═══ NOTIFICATIONS ═══ */}
      <div style={S.notificationContainer}>
        {notifications.map((notif, i) => (
          <div key={notif.id} style={{...S.notification, background: notif.type === "success" ? theme.accent : theme.card, color: notif.type === "success" ? theme.bg : theme.text, animationDelay: `${i*0.1}s`}}>
            {notif.message}
          </div>
        ))}
      </div>

      {/* ═══ TOP NAV BAR ═══ */}
      {screen !== SCREENS.MAP && (
        <div style={{...S.topNav, background: `${theme.bgAlt}dd`, borderBottom: `1px solid ${theme.border}`}}>
          <button className="nav-btn" style={{...S.navBtn, color: theme.textSub}} onClick={() => { stopSpeech(); setScreen(SCREENS.MAP); }}>← Map</button>
          <div style={{...S.navCenter, color: theme.accent}}>
            {current?.title || "Bible Adventure"}
            {isOffline && <span style={{...S.offlineBadge, marginLeft: 8}}>🔴</span>}
          </div>
          <div style={S.navRight}>
            <button className="nav-btn" style={{...S.navBtn, color: theme.textSub}} onClick={() => setScreen(SCREENS.BADGES)}>🏅</button>
            <button className="nav-btn" style={{...S.navBtn, color: theme.textSub}} onClick={() => setScreen(SCREENS.STATS)}>📊</button>
            <button className="nav-btn" style={{...S.navBtn, color: theme.textSub}} onClick={() => setScreen(SCREENS.SETTINGS)}>⚙️</button>
          </div>
        </div>
      )}

      {/* ═══ BADGE POPUP ═══ */}
      {newBadge && (
        <div style={S.overlay} onClick={() => setNewBadge(null)}>
          <div style={{...S.badgePop, animation:"slideUp 0.4s cubic-bezier(0.34,1.56,0.64,1)"}}>
            <div style={{fontSize:64,marginBottom:10,animation:"pulse 1s infinite"}}>{newBadge.icon}</div>
            <div style={S.bpSub}>New Badge Earned!</div>
            <div style={S.bpTitle}>{newBadge.title}</div>
            <div style={S.bpDesc}>{newBadge.desc}</div>
            <button className="btn" style={S.btnPrimary} onClick={() => setNewBadge(null)}>Continue</button>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          MAP SCREEN
      ═══════════════════════════════════════════════════════════════════ */}
      {screen === SCREENS.MAP && (
        <div style={S.page}>
          <div style={S.header}>
            <div>
              <div style={{...S.appName, color: theme.accent}}>📖 Bible Adventure</div>
              <div style={{...S.appTag, color: theme.textMuted}}>50 Stories Through Scripture</div>
            </div>
            <div style={S.headerRight}>
              <button className="nav-btn" style={{...S.iconBtn, background: theme.card, border: `1px solid ${theme.border}`, color: theme.textSub}} onClick={() => setShowShareModal(true)}>📤</button>
              <button className="nav-btn" style={{...S.iconBtn, background: theme.card, border: `1px solid ${theme.border}`, color: theme.textSub}} onClick={() => setScreen(SCREENS.BADGES)}>🏅 {badges.length}</button>
              <button className="nav-btn" style={{...S.iconBtn, background: theme.card, border: `1px solid ${theme.border}`, color: theme.textSub}} onClick={() => setScreen(SCREENS.STATS)}>📊</button>
              <button className="nav-btn" style={{...S.iconBtn, background: theme.card, border: `1px solid ${theme.border}`, color: theme.textSub}} onClick={() => setScreen(SCREENS.SETTINGS)}>⚙️</button>
            </div>
          </div>

          {/* Quick Stats Widget */}
          <div style={{...S.quickStats, background: theme.card, border: `1px solid ${theme.border}`}}>
            <div style={S.quickStat}>
              <div style={{...S.quickStatValue, color: theme.accent}}>{completed.length}/{LEVELS.length}</div>
              <div style={{...S.quickStatLabel, color: theme.textMuted}}>Completed</div>
            </div>
            <div style={{...S.quickStatDivider, background: theme.border}} />
            <div style={S.quickStat}>
              <div style={{...S.quickStatValue, color: theme.accent}}>{totalReadingTime}m</div>
              <div style={{...S.quickStatLabel, color: theme.textMuted}}>Total Time</div>
            </div>
            <div style={{...S.quickStatDivider, background: theme.border}} />
            <div style={S.quickStat}>
              <div style={{...S.quickStatValue, color: theme.accent}}>{Math.round(progressPct)}%</div>
              <div style={{...S.quickStatLabel, color: theme.textMuted}}>Progress</div>
            </div>
          </div>

          <div style={{...S.streakBanner, background: `linear-gradient(135deg, ${theme.accent} 0%, ${theme.accent}dd 100%)`}}>
            <div style={S.streakIcon}>🔥</div>
            <div>
              <div style={{...S.streakNum, color: settings.theme === "light" ? theme.bg : "#fff"}}>{streak} Day Streak</div>
              <div style={{...S.streakSub, color: settings.theme === "light" ? theme.bgAlt : "#ffffff99"}}>Keep going!</div>
            </div>
          </div>

          {/* Daily Challenge */}
          {dailyChallenge && (
            <div style={{...S.challengeCard, background: `linear-gradient(135deg, ${theme.accent} 0%, ${theme.accent}dd 100%)`, animation:"slideDown 0.6s ease"}} onClick={openDailyChallenge}>
              <div style={S.challengeHeader}>
                <span style={{fontSize:24}}>📅</span>
                <div>
                  <div style={{...S.challengeTitle, color: settings.theme === "light" ? theme.bg : "#fff"}}>Today's Challenge</div>
                  <div style={{...S.challengeSub, color: settings.theme === "light" ? theme.bgAlt : "#ffffff99"}}>Complete to boost your streak</div>
                </div>
              </div>
              <div style={{...S.challengeStory, color: settings.theme === "light" ? theme.text : "#fff"}}>
                <span style={{fontSize:28,marginRight:8}}>{dailyChallenge.icon}</span>
                {dailyChallenge.title}
              </div>
            </div>
          )}

          <div style={S.progressSection}>
            <div style={S.progressLabel}>
              <span style={{...S.progressTitle, color: theme.accent}}>Your Journey</span>
              <span style={{...S.progressCount, color: theme.textMuted}}>{completed.length} / {LEVELS.length}</span>
            </div>
            <div style={{...S.progressBar, background: theme.card}}>
              <div style={{...S.progressFill, width:`${progressPct}%`, background: `linear-gradient(90deg, ${theme.accent} 0%, ${theme.accent}dd 100%)`}} />
            </div>
          </div>

          {/* Search & Filter */}
          <div style={S.searchSection}>
            <input
              type="text"
              placeholder="🔍 Search stories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{...S.searchInput, background: theme.card, border: `1px solid ${theme.border}`, color: theme.text}}
            />
          </div>

          <div style={S.filterChips}>
            {eras.map(era => (
              <button
                key={era}
                onClick={() => { haptic("light"); setFilterEra(era); }}
                style={{
                  ...S.filterChip,
                  background: filterEra === era ? theme.accent : theme.card,
                  color: filterEra === era ? (settings.theme === "light" ? theme.bg : "#fff") : theme.text,
                  border: `1px solid ${filterEra === era ? theme.accent : theme.border}`
                }}
              >
                {era === "all" ? "All Stories" : era}
              </button>
            ))}
          </div>

          <div style={S.grid}>
            {filteredLevels.length === 0 ? (
              <div style={{...S.emptyState, color: theme.textMuted, gridColumn: "1 / -1"}}>
                No stories found matching your search
              </div>
            ) : (
              filteredLevels.map((lv, idx) => {
                const prevCompleted = idx === 0 || completed.includes(LEVELS[idx-1].id);
                const isCompleted = completed.includes(lv.id);
                const isLocked = !prevCompleted;
                const isFavorite = favorites.includes(lv.id);

                return (
                  <div
                    key={lv.id}
                    className="card"
                    onClick={() => !isLocked && openLevel(lv)}
                    style={{
                      ...S.levelCard,
                      background: isCompleted ? `linear-gradient(135deg, ${theme.accent}40 0%, ${theme.accent}20 100%)` : theme.card,
                      border: `1px solid ${isCompleted ? theme.accent : theme.border}`,
                      opacity: isLocked ? 0.4 : 1,
                      cursor: isLocked ? "not-allowed" : "pointer",
                      position: "relative"
                    }}
                  >
                    {isFavorite && <div style={S.favoriteIndicator}>⭐</div>}
                    <div style={S.lvIcon}>{isLocked ? "🔒" : lv.icon}</div>
                    <div style={{...S.lvTitle, color: theme.text}}>{lv.title}</div>
                    <div style={{...S.lvEra, color: theme.textMuted}}>{lv.era}</div>
                    <div style={{...S.lvTime, color: theme.textMuted}}>⏱️ {getReadingTime(lv)}m</div>
                    {isCompleted && <div style={{...S.completeBadge, background: theme.accent, color: settings.theme === "light" ? theme.bg : "#fff"}}>✓ Done</div>}
                    {!isLocked && !isCompleted && (
                      <button
                        onClick={(e) => { e.stopPropagation(); toggleFavorite(lv.id); }}
                        style={{...S.favoriteBtn, color: isFavorite ? "#ffd700" : theme.textMuted}}
                      >
                        {isFavorite ? "★" : "☆"}
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div style={S.overlay} onClick={() => setShowShareModal(false)}>
          <div style={{...S.modal, background: theme.card, border: `1px solid ${theme.border}`}} onClick={(e) => e.stopPropagation()}>
            <div style={{...S.modalTitle, color: theme.text}}>Share Your Progress</div>
            <div style={{...S.modalDesc, color: theme.textSub}}>
              Show off your Bible study journey!
            </div>
            <div style={{...S.shareStats, background: theme.bgAlt, border: `1px solid ${theme.border}`}}>
              <div style={{...S.shareStat, color: theme.accent}}>{completed.length}/{LEVELS.length} Stories</div>
              <div style={{...S.shareStat, color: theme.accent}}>{streak}🔥 Streak</div>
              <div style={{...S.shareStat, color: theme.accent}}>{badges.length}🏅 Badges</div>
            </div>
            <button className="btn" style={{...S.btnPrimary, background: theme.accent}} onClick={shareProgress}>Share Now</button>
            <button className="btn" style={{...S.btnSecondary, background: theme.bgAlt, color: theme.textSub}} onClick={() => setShowShareModal(false)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// STYLES
// ═════════════════════════════════════════════════════════════════════════════
const S = {
  page: { maxWidth: 800, margin: "0 auto", padding: "20px 16px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 },
  appName: { fontSize: 28, fontWeight: 700, letterSpacing: -0.5 },
  appTag: { fontSize: 13, marginTop: 4, opacity: 0.8 },
  headerRight: { display: "flex", gap: 8, alignItems: "center" },
  iconBtn: { padding: "8px 12px", borderRadius: 8, fontSize: 13, fontWeight: 600, border: "none", cursor: "pointer" },
  
  quickStats: { display: "flex", padding: "16px 0", borderRadius: 12, marginBottom: 16, justifyContent: "space-around" },
  quickStat: { textAlign: "center" },
  quickStatValue: { fontSize: 24, fontWeight: 700 },
  quickStatLabel: { fontSize: 11, marginTop: 4, textTransform: "uppercase", letterSpacing: 0.5 },
  quickStatDivider: { width: 1, opacity: 0.3 },

  streakBanner: { borderRadius: 12, padding: 16, display: "flex", alignItems: "center", gap: 12, marginBottom: 16 },
  streakIcon: { fontSize: 32 },
  streakNum: { fontSize: 20, fontWeight: 700 },
  streakSub: { fontSize: 13, marginTop: 2 },

  challengeCard: { borderRadius: 12, padding: 16, marginBottom: 16, cursor: "pointer" },
  challengeHeader: { display: "flex", gap: 12, alignItems: "center", marginBottom: 12 },
  challengeTitle: { fontSize: 16, fontWeight: 700 },
  challengeSub: { fontSize: 13, marginTop: 2 },
  challengeStory: { fontSize: 18, fontWeight: 600, display: "flex", alignItems: "center" },

  progressSection: { marginBottom: 20 },
  progressLabel: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  progressTitle: { fontSize: 15, fontWeight: 600 },
  progressCount: { fontSize: 13 },
  progressBar: { height: 8, borderRadius: 999, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 999, transition: "width 0.5s cubic-bezier(0.4,0,0.2,1)" },

  searchSection: { marginBottom: 16 },
  searchInput: { width: "100%", padding: "12px 16px", borderRadius: 10, fontSize: 15, outline: "none" },

  filterChips: { display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 },
  filterChip: { padding: "8px 14px", borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: "pointer", border: "none", transition: "all 0.2s" },

  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 12 },
  levelCard: { borderRadius: 12, padding: 16, textAlign: "center", animation: "fadeIn 0.4s ease" },
  lvIcon: { fontSize: 40, marginBottom: 8 },
  lvTitle: { fontSize: 15, fontWeight: 600, marginBottom: 4 },
  lvEra: { fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  lvTime: { fontSize: 11, marginTop: 8 },
  completeBadge: { marginTop: 8, padding: "4px 10px", borderRadius: 999, fontSize: 11, fontWeight: 700, display: "inline-block" },
  favoriteBtn: { position: "absolute", top: 8, right: 8, background: "transparent", border: "none", fontSize: 20, cursor: "pointer", lineHeight: 1 },
  favoriteIndicator: { position: "absolute", top: 8, left: 8, fontSize: 16 },
  emptyState: { textAlign: "center", padding: 40, fontSize: 15 },

  topNav: { position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(10px)", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px" },
  navBtn: { background: "none", border: "none", fontSize: 15, fontWeight: 600, cursor: "pointer" },
  navCenter: { fontSize: 16, fontWeight: 700 },
  navRight: { display: "flex", gap: 12 },
  offlineBadge: { fontSize: 10 },

  notificationContainer: { position: "fixed", top: 20, right: 20, zIndex: 1000, display: "flex", flexDirection: "column", gap: 8, maxWidth: 300 },
  notification: { padding: "12px 16px", borderRadius: 10, fontSize: 14, fontWeight: 600, boxShadow: "0 4px 12px rgba(0,0,0,0.2)", animation: "slideDown 0.3s ease" },

  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999, backdropFilter: "blur(4px)" },
  badgePop: { background: "#1a1712", borderRadius: 16, padding: 32, textAlign: "center", maxWidth: 320, border: "2px solid #d4a574" },
  bpSub: { fontSize: 13, color: "#b8ad94", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 },
  bpTitle: { fontSize: 24, fontWeight: 700, color: "#d4a574", marginBottom: 8 },
  bpDesc: { fontSize: 15, color: "#e8dcc8", marginBottom: 20 },
  btnPrimary: { width: "100%", padding: "12px 24px", borderRadius: 10, fontSize: 15, fontWeight: 700, border: "none", cursor: "pointer", background: "#d4a574", color: "#0a0908" },

  modal: { borderRadius: 16, padding: 24, maxWidth: 400, width: "90%" },
  modalTitle: { fontSize: 20, fontWeight: 700, marginBottom: 8 },
  modalDesc: { fontSize: 14, marginBottom: 20 },
  shareStats: { padding: 16, borderRadius: 10, marginBottom: 16, display: "flex", flexDirection: "column", gap: 8 },
  shareStat: { fontSize: 15, fontWeight: 600 },
  btnSecondary: { width: "100%", padding: "12px 24px", borderRadius: 10, fontSize: 15, fontWeight: 700, border: "none", cursor: "pointer", marginTop: 8 },
};

export default BibleAdventure;
