# 📖 Bible Adventure - Interactive Bible Learning App

A beautiful, interactive React application for learning Bible stories with quizzes, progress tracking, and achievements.

## ✨ Features

- **50 Complete Bible Stories** - From Creation to Resurrection
- **Interactive Quizzes** - 3 questions per story with instant feedback  
- **Progress Tracking** - Track completed stories, streaks, and achievements
- **Badge System** - Earn badges for milestones and special achievements
- **Offline Support** - Works offline with local storage
- **Daily Challenges** - Random story challenges each day
- **Search & Filter** - Find stories by name or biblical era
- **Favorites** - Mark and save favorite stories
- **Multiple Themes** - Dark, Light, and Sepia themes
- **Persistent Storage** - All progress saves automatically
- **KJV Scripture** - Authentic King James Version verses
- **Study Notes** - Theological insights and cross-references

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/bible-adventure.git

# Navigate to project directory
cd bible-adventure

# Install dependencies
npm install

# Start the development server
npm start
```

The app will open at `http://localhost:3000`

### Building for Production

```bash
npm run build
```

## 📁 Project Structure

```
bible-adventure/
├── src/
│   ├── App.js                 # Main React component
│   ├── stories/
│   │   ├── batch_1.js        # Stories 1-10
│   │   ├── batch_2.js        # Stories 11-20
│   │   ├── batch_3.js        # Stories 21-30
│   │   ├── batch_4.js        # Stories 31-40
│   │   └── batch_5.js        # Stories 41-50
│   └── index.js              # Entry point
├── public/
│   └── index.html
├── package.json
└── README.md
```

## 📚 Story Coverage

### Old Testament (36 stories)
- **Creation Era**: Creation, Garden of Eden
- **Early Earth**: Cain & Abel, Noah's Ark, Tower of Babel  
- **Patriarchs**: Abraham, Isaac, Jacob, Joseph (13 stories)
- **Exodus**: Moses, Red Sea, Ten Commandments, Golden Calf
- **Kingdom**: Joshua, Judges, Kings, Prophets (12 stories)
- **Captivity**: Daniel, Esther, Exile prophets

### New Testament (14 stories)
- **Birth & Early Life**: Jesus's birth, Wise Men, Baptism
- **Ministry**: Calling disciples, Sermon on the Mount, Miracles (7 stories)
- **Passion**: Last Supper, Crucifixion, Resurrection

## 🎮 How to Play

1. **Start with Story 1** - Stories unlock sequentially
2. **Read the Story** - Learn about the biblical event
3. **Read Scripture** - Authentic KJV verses included
4. **Take the Quiz** - Answer 3 questions (need 2/3 to pass)
5. **Unlock Next Story** - Continue your journey through the Bible
6. **Earn Badges** - Collect achievements for milestones

## 🏅 Badge System

### Progress Badges
- 👣 First Step - Complete 1 story
- 📚 Learner - Complete 3 stories
- 🔍 Seeker - Complete 5 stories
- 🙏 Devoted - Complete 10 stories
- 🗺️ Explorer - Complete 15 stories
- ✝️ Disciple - Complete 20 stories
- 📖 Scholar - Complete 30 stories
- 👨‍🏫 Teacher - Complete 40 stories
- 🎓 Master - Complete all 50 stories!

### Special Badges
- ⭐ Perfect Start - Get 3/3 on first story
- 🔥 Week Warrior - 7-day streak
- 📅 Month Master - 30-day streak
- 🌅 Early Bird - Complete story before 8am
- 🦉 Night Owl - Complete story after 10pm
- ⚡ Speed Reader - Complete quiz in under 60s

## 🛠️ Technology Stack

- **React 18** - UI framework
- **JavaScript ES6+** - Modern JavaScript
- **Local Storage API** - Persistent data storage
- **CSS-in-JS** - Inline styling for simplicity
- **No external dependencies** - Lightweight and fast

## 📱 Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

### Adding/Improving Stories

1. Fork the repository
2. Edit story batch files in `src/stories/`
3. Follow the existing structure:
   - `title`: Story name
   - `summary`: 2-3 paragraph summary
   - `scripture`: Array of KJV verses with references
   - `questions`: 3 quiz questions with 4 options each
   - `studyNotes`: Theological insights and cross-references
4. Submit a pull request

### Reporting Issues

Found a bug or have a suggestion? [Open an issue](https://github.com/yourusername/bible-adventure/issues)

## 📜 Scripture Source

All scripture quotations are from the King James Version (KJV), which is in the public domain.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Biblical content sourced from the King James Version
- Story summaries and study notes compiled from public domain commentaries
- Icon emoji from Unicode standard

## 📧 Contact

Have questions or suggestions? Open an issue or contact the maintainers.

---

**Made with ❤️ for Bible education**

## 🎯 Roadmap

- [ ] Add audio narration for stories
- [ ] Multiple Bible translations (ESV, NIV, etc.)
- [ ] Downloadable study guides
- [ ] Multiplayer quiz mode
- [ ] Mobile app (React Native)
- [ ] Additional languages
- [ ] Expanded to 100 stories
- [ ] Parent/teacher dashboard
- [ ] Print certificates for completion

## 💡 Tips for Users

**Maximizing Learning:**
- Read the study notes after completing each story
- Review scripture references in your own Bible
- Share your progress with friends
- Set a daily goal (e.g., 1 story per day)
- Complete the daily challenge for variety

**Building Streaks:**
- Complete at least one quiz daily
- Enable notifications for reminders
- Morning and evening are best times
- Make it a family activity

**For Teachers/Parents:**
- Use for family devotions
- Assign specific stories for study
- Discuss the study notes together
- Create friendly competitions with badges
- Print quiz questions for review

---

⭐ **Star this repo if you find it helpful!**
